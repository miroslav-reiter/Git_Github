# Toto je len test subor

print("Ide to")