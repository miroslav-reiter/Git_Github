# Názov aplikácie

Stručný popis Python aplikácie a jej účelu.

## Obsah

- [Inštalácia](#inštalácia)
- [Požiadavky](#požiadavky)
- [Použitie](#použitie)
- [Testovanie](#testovanie)
- [Prispievanie](#prispievanie)
- [Licencia](#licencia)
- [Kontakty](#kontakty)

## Inštalácia

1. Klonujte tento repozitár:
    ```bash
    git clone https://github.com/vaša-užívateľské-meno/názov-aplikácie.git
    ```
2. Prejdite do adresára projektu:
    ```bash
    cd názov-aplikácie
    ```
3. Vytvorte virtuálne prostredie:
    ```bash
    python -m venv venv
    ```
4. Aktivujte virtuálne prostredie:
    - Na Windows:
        ```bash
        venv\Scripts\activate
        ```
    - Na Mac/Linux:
        ```bash
        source venv/bin/activate
        ```
5. Nainštalujte potrebné závislosti:
    ```bash
    pip install -r requirements.txt
    ```

## Požiadavky

- Python 3.x
- Knižnice uvedené v `requirements.txt`

Príklad obsahu `requirements.txt`:

```txt
requests==2.25.1
flask==2.0.1
numpy==1.19.5
