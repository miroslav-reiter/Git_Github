# Markdown Upozornenia
https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts

> [!NOTE]
> Useful information that users should know, even when skimming content.  
> Užitočné informácie, ktoré by používatelia mali vedieť aj pri prezeraní obsahu.  

> [!TIP]
> Helpful advice for doing things better or more easily.  
> Užitočné rady, ako robiť veci lepšie alebo jednoduchšie.  

> [!IMPORTANT]
> Key information users need to know to achieve their goal.  
> Kľúčové informácie, ktoré používatelia potrebujú vedieť, aby dosiahli svoj cieľ.  

> [!WARNING]
> Urgent info that needs immediate user attention to avoid problems.  
> Naliehavé informácie, ktoré si vyžadujú okamžitú pozornosť používateľa, aby sa predišlo problémom.  

> [!CAUTION]
> Advises about risks or negative outcomes of certain actions.  
> Radí o rizikách alebo negatívnych dôsledkoch určitých činností.  




> :warning: **Warning:** Nestláčajte veľké červené tlačidlo.

> :memo: **Note:** Východy slnka sú krásne.

> :bulb: **Tip:** Nezabudnite si vážiť maličkosti v živote.